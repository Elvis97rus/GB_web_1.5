let a = b => {
    return b + 20
};

// module.exports = {
//     a,
//     b
// };
module.exports = a;