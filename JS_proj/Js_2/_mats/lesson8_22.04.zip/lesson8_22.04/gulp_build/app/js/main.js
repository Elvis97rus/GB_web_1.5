let message = (text) => {
    console.log(text);
};
message('Gulp works!!!');